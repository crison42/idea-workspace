create definer = root@localhost view project_color_part_count as
select `myspj`.`j`.`JNO`                 AS `ProjectNo`,
       `myspj`.`j`.`JNAME`               AS `ProjectName`,
       `myspj`.`p`.`COLOR`               AS `COLOR`,
       count(distinct `myspj`.`p`.`PNO`) AS `PartCount`
from ((`myspj`.`spj` `sp` join `myspj`.`j` on ((`sp`.`JNO` = `myspj`.`j`.`JNO`))) join `myspj`.`p`
      on ((`sp`.`PNO` = `myspj`.`p`.`PNO`)))
group by `myspj`.`j`.`JNO`, `myspj`.`p`.`COLOR`;

