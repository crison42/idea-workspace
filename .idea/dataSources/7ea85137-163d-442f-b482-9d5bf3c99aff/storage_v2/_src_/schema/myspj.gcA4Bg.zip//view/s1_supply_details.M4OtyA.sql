create definer = root@localhost view s1_supply_details as
select `sp`.`SNO`          AS `SupplierNo`,
       `sp`.`PNO`          AS `PartNo`,
       `myspj`.`p`.`PNAME` AS `PartName`,
       `sp`.`JNO`          AS `ProjectNo`,
       `sp`.`QTY`          AS `Quantity`
from (`myspj`.`spj` `sp` join `myspj`.`p` on ((`sp`.`PNO` = `myspj`.`p`.`PNO`)))
where (`sp`.`SNO` = 'S1');

