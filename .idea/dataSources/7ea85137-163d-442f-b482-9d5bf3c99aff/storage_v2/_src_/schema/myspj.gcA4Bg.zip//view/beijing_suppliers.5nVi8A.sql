create definer = root@localhost view beijing_suppliers as
select `myspj`.`s`.`SNO` AS `SupplierNo`, `myspj`.`s`.`SNAME` AS `SupplierName`, `myspj`.`s`.`CITY` AS `CITY`
from `myspj`.`s`
where (`myspj`.`s`.`CITY` = '北京');

