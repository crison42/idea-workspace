create
    definer = root@localhost procedure pro1(IN e decimal(10, 2), IN idSource int, IN idTarget int)
BEGIN
	DECLARE
		sourcemoney DECIMAL ( 10, 2 );
	START TRANSACTION;-- 检查转出账户余额是否足够
	SELECT
		money INTO sourcemoney 
	FROM
		account 
	WHERE
		id = idSource;
	IF
		sourcemoney < e THEN
			ROLLBACK;
		SIGNAL SQLSTATE '45000' 
		SET MESSAGE_TEXT = '转出账户余额不足';
		
	END IF;-- 检查转出、转入账户是否存在
	IF
		NOT EXISTS ( SELECT * FROM account WHERE id = idSource ) 
		OR NOT EXISTS ( SELECT * FROM account WHERE id = idTarget ) THEN
			ROLLBACK;
		SIGNAL SQLSTATE '45000' 
		SET MESSAGE_TEXT = '转出或转入账户不存在';
		
	END IF;-- 更新转出账户余额
	UPDATE account 
	SET money = money - e 
	WHERE
		id = idSource;-- 更新转入账户余额
	UPDATE account 
	SET money = money + e 
	WHERE
		id = idTarget;
	COMMIT;
	
END;

