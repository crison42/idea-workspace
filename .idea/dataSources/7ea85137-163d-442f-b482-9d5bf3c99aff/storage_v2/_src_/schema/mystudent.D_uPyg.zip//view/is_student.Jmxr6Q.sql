create definer = root@localhost view is_student as
select `mystudent`.`student`.`Sno`   AS `Sno`,
       `mystudent`.`student`.`Sname` AS `Sname`,
       `mystudent`.`student`.`Sage`  AS `Sage`
from `mystudent`.`student`
where (`mystudent`.`student`.`Sdept` = 'IS');

