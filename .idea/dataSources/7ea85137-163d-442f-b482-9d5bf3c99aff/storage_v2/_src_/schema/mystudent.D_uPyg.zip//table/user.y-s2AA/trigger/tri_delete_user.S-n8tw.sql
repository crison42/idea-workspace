create definer = root@localhost trigger tri_delete_user
    after delete
    on user
    for each row
begin
    INSERT INTO user_history(user_id, operatetype, operatetime) VALUES (old.id, 'delete a user', now());
end;

