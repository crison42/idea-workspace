create definer = root@localhost view student_sc as
select `mystudent`.`student`.`Sno`   AS `sno`,
       `mystudent`.`student`.`Sname` AS `sname`,
       `mystudent`.`student`.`Ssex`  AS `ssex`,
       `mystudent`.`student`.`Sage`  AS `sage`,
       `mystudent`.`student`.`Sdept` AS `sdept`,
       `mystudent`.`sc`.`Cno`        AS `cno`,
       `mystudent`.`sc`.`Grade`      AS `grade`
from (`mystudent`.`student` join `mystudent`.`sc`)
where (`mystudent`.`student`.`Sno` = `mystudent`.`sc`.`Sno`);

