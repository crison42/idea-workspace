create
    definer = root@localhost procedure UpdateCourseInfo(IN p_cno int, IN p_cname varchar(20), IN p_cpno int, IN p_ccredit int)
BEGIN
    UPDATE course SET Cname = p_cname, Cpno = p_cpno, Ccredit = p_ccredit WHERE Cno = p_cno;
END;

