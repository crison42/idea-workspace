create definer = root@localhost trigger CalculateMcsxOnUpdate
    before update
    on course
    for each row
BEGIN
    DECLARE pinyin VARCHAR(10);
    SET pinyin = 'GetFirstLetter(NEW.Cname)';
    SET NEW.mcsx = pinyin;
END;

