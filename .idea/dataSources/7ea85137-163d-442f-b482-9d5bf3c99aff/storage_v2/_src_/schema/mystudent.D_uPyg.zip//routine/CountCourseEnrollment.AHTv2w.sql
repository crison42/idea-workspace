create
    definer = root@localhost procedure CountCourseEnrollment(IN p_cno int, OUT p_enrollment int)
BEGIN
    SELECT COUNT(*) INTO p_enrollment FROM sc WHERE Cno = p_cno;
END;

