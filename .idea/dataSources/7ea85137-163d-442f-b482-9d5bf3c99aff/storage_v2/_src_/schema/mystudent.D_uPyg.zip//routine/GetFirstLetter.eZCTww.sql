create
    definer = root@localhost function GetFirstLetter(p_chinese varchar(255)) returns varchar(10) deterministic
BEGIN
    DECLARE pinyin VARCHAR(10);
    DECLARE len INT;
    DECLARE i INT;
    DECLARE char_code INT;
    DECLARE first_letter VARCHAR(1);
    
    SET pinyin = '';
    SET len = CHAR_LENGTH(p_chinese);
    SET i = 1;
    
    WHILE i <= len DO
        SET char_code = ASCII(SUBSTRING(p_chinese, i, 1));
        IF char_code >= 19968 AND char_code <= 40869 THEN
            SET first_letter = SUBSTRING(pinyin_convert(char_code), 1, 1);
            SET pinyin = CONCAT(pinyin, first_letter);
        ELSE
            SET pinyin = CONCAT(pinyin, SUBSTRING(p_chinese, i, 1));
        END IF;
        
        SET i = i + 1;
    END WHILE;
    
    RETURN pinyin;
END;

