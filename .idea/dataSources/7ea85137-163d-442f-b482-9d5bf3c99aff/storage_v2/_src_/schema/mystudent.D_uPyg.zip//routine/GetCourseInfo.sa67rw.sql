create
    definer = root@localhost procedure GetCourseInfo(IN p_cno int)
BEGIN
    SELECT * FROM course WHERE Cno = p_cno;
END;

