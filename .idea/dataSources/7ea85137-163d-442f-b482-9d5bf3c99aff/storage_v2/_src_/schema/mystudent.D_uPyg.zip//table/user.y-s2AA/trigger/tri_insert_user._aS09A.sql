create definer = root@localhost trigger tri_insert_user
    after insert
    on user
    for each row
begin
    INSERT INTO user_history(user_id, operatetype, operatetime) VALUES (new.id, 'add a user',  now());
end;

