create definer = root@localhost view is_student1 as
select `mystudent`.`student`.`Sno`   AS `Sno`,
       `mystudent`.`student`.`Sname` AS `Sname`,
       `mystudent`.`student`.`Sage`  AS `Sage`,
       `mystudent`.`student`.`Sdept` AS `Sdept`
from `mystudent`.`student`
where (`mystudent`.`student`.`Sdept` = 'IS');

