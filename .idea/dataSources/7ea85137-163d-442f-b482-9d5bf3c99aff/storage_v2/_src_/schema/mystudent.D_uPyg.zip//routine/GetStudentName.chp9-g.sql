create
    definer = root@localhost procedure GetStudentName(IN p_sno varchar(10), OUT p_sname varchar(20))
BEGIN
    SELECT Sname INTO p_sname FROM student WHERE Sno = p_sno;
END;

