create definer = root@localhost trigger tri_update_user
    after update
    on user
    for each row
begin
    INSERT INTO user_history(user_id,operatetype, operatetime) VALUES (new.id, 'update a user', now());
end;

